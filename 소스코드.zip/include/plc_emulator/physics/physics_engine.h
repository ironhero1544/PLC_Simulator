// physics_engine.h
//
// Multi-domain physics simulation engine.
// ?�중 ?�메??물리 ?��??�이???�진.

/**
 * @file PhysicsEngine.h
 * @brief Comprehensive C-style physics engine interface for industrial PLC
 * simulation
 * ?�업??PLC ?��??�이?�을 ?�한 ?�괄?�인 C ?��???물리 ?�진 ?�터?�이??
 *
 * CRITICAL SYSTEM ARCHITECTURE:
 * This header defines a unified physics engine that replaces hardcoded
 * simulation logic with accurate, real-world physics calculations for
 * electrical, pneumatic, and mechanical systems in industrial automation
 * environments.
 * ?�심 ?�스???�키?�처:
 * ???�더???�드코딩???��??�이??로직???�업 ?�동???�경???�기, 공압, 기계 ?�스?�에 ?�??
 * ?�확???�제 물리 계산?�로 ?�체하???�합 물리 ?�진???�의?�니??
 *
 * CRASH PREVENTION DESIGN:
 * - C-style function pointers provide memory-safe modular interfaces
 * - Comprehensive error code system enables robust error handling
 * - Bounds checking and validation throughout all data structures
 * - Memory pool management prevents allocation failures
 * - State validation functions prevent invalid operations
 * 충돌 방�? ?�계:
 * - C ?��????�수 ?�인?�는 메모�??�전 모듈???�터?�이?��? ?�공?�니??
 * - ?�괄?�인 ?�류 코드 ?�스?�으�?강력???�류 처리가 가?�합?�다.
 * - 모든 ?�이??구조??걸친 경계 검??�??�효??검�?
 * - 메모�??� 관리로 ?�당 ?�패�?방�??�니??
 * - ?�태 ?�효??검�??�수�??�못???�산??방�??�니??
 *
 * INDUSTRIAL SAFETY FEATURES:
 * - Real-time performance monitoring and quality metrics
 * - Numerical convergence validation for stability
 * - Physical consistency checking
 * - Graceful degradation on component failures
 * ?�업 ?�전 기능:
 * - ?�시�??�능 모니?�링 �??�질 메트�?
 * - ?�정?�을 ?�한 ?�치 ?�렴 ?�효??검�?
 * - 물리???��???검??
 * - 구성 ?�소 ?�애 ???�상?�인 ?�능 ?�??
 */

#ifndef PLC_EMULATOR_INCLUDE_PLC_EMULATOR_PHYSICS_PHYSICS_ENGINE_H_
#define PLC_EMULATOR_INCLUDE_PLC_EMULATOR_PHYSICS_PHYSICS_ENGINE_H_

#include "plc_emulator/core/data_types.h"
#include "plc_emulator/physics/physics_network.h"
#include "plc_emulator/physics/physics_states.h"

namespace plc {
    struct PhysicsEngine;

    typedef void (*PhysicsWarningCallback)(const char* message);
    void SetPhysicsWarningCallback(PhysicsWarningCallback callback);
    void NotifyPhysicsWarning(const char* message);
/**
 * @brief Real-time simulation performance statistics for monitoring and
 * optimization
 * 모니?�링 �?최적?��? ?�한 ?�시�??��??�이???�능 ?�계
 *
 * CRITICAL PERFORMANCE MONITORING:
 * This structure provides comprehensive metrics for detecting performance
 * issues that could lead to real-time constraint violations in industrial
 * systems.
 * 중요 ?�능 모니?�링:
 * ??구조체는 ?�업 ?�스?�에???�시�??�약 조건 ?�반?�로 ?�어�????�는 ?�능 문제�?
 * 감�??�기 ?�한 ?�괄?�인 메트�?�� ?�공?�니??
 *
 * MONITORING PURPOSE:
 * - Early detection of numerical instability
 * - Performance degradation analysis
 * - Memory usage tracking
 * - Convergence failure detection
 * - System health assessment
 * 모니?�링 목적:
 * - ?�치??불안?�성??조기 발견
 * - ?�능 ?�??분석
 * - 메모�??�용??추적
 * - ?�렴 ?�패 감�?
 * - ?�스???�태 ?��?
 */
    typedef struct PhysicsPerformanceStats {
        // Computation time statistics
        // 계산 ?�간 ?�계
        float totalComputeTime;     // Total computation time [ms] // �?계산?�간 [ms]
        float electricalSolveTime;  // Electrical solve time [ms] // ?�기 ?�석?�간 [ms]
        float pneumaticSolveTime;   // Pneumatic solve time [ms] // 공압 ?�석?�간 [ms]
        float mechanicalSolveTime;  // Mechanical solve time [ms] // 기계 ?�석?�간 [ms]
        float networkBuildTime;     // Network build time [ms] // ?�트?�크 구성?�간 [ms]

        // Convergence statistics
        // ?�렴???�계
        int electricalIterations;  // Number of electrical solver iterations // ?�기 ?�버 반복 ?�수
        int pneumaticIterations;   // Number of pneumatic solver iterations // 공압 ?�버 반복 ?�수
        bool electricalConverged;  // Whether electrical solver converged // ?�기 ?�버 ?�렴 ?��?
        bool pneumaticConverged;   // Whether pneumatic solver converged // 공압 ?�버 ?�렴 ?��?
        bool mechanicalStable;     // Mechanical system stability // 기계 ?�스???�정??

        // Network size statistics
        // ?�트?�크 ?�기 ?�계
        int electricalNodes;  // Number of electrical network nodes // ?�기 ?�트?�크 ?�드 ??
        int electricalEdges;  // Number of electrical network edges // ?�기 ?�트?�크 ?��? ??
        int pneumaticNodes;   // Number of pneumatic network nodes // 공압 ?�트?�크 ?�드 ??
        int pneumaticEdges;   // Number of pneumatic network edges // 공압 ?�트?�크 ?��? ??
        int mechanicalNodes;  // Number of mechanical system nodes // 기계 ?�스???�드 ??
        int mechanicalEdges;  // Number of mechanical system edges // 기계 ?�스???��? ??

        // Quality metrics
        // ?�질 지??
        float electricalResidual;  // Electrical solver residual error // ?�기 ?�버 ?�여?�차
        float pneumaticResidual;   // Pneumatic solver residual error // 공압 ?�버 ?�여?�차
        float mechanicalEnergy;    // Total mechanical system energy [J] // 기계 ?�스??�??�너지 [J]
        float powerConsumption;    // Total power consumption [W] // �??�비?�력 [W]
        float airConsumption;      // Total air consumption [L/min] // �?공기?�모??[L/min]

        // Real-time performance
        // ?�시�??�능
        float simulationFPS;  // Simulation FPS // ?��??�이??FPS
        float realTimeRatio;  // Simulation speed ratio to real-time // ?�시�??��??��??�이???�도�?
        float memoryUsage;    // Memory usage [MB] // 메모�??�용??[MB]
    } PhysicsPerformanceStats;

/**
 * @brief Comprehensive simulation results for application interface
 * ?�플리�??�션 ?�터?�이?��? ?�한 ?�괄?�인 ?��??�이??결과
 *
 * HIGH-LEVEL INTERFACE:
 * This structure provides aggregated physics simulation results that the
 * application can safely consume without accessing low-level physics data.
 * ?�위 ?��? ?�터?�이??
 * ??구조체는 ?�플리�??�션???�위 ?��? 물리 ?�이?�에 ?�근?��? ?�고???�전?�게 ?�용?????�는
 * 집계??물리 ?��??�이??결과�??�공?�니??
 *
 * DATA SAFETY FEATURES:
 * - Validation flag prevents use of invalid results
 * - Component count bounds checking
 * - Separate arrays for different physics domains
 * - Performance statistics included for monitoring
 * ?�이???�전 기능:
 * - ?�효??검???�래그는 ?�못??결과???�용??방�??�니??
 * - 컴포?�트 ??경계 검??
 * - ?�른 물리 ?�메?�을 ?�한 별도??배열
 * - 모니?�링???�한 ?�능 ?�계 ?�함
 */
    typedef struct PhysicsSimulationResult {
        // Overall simulation state
        // ?�체 ?��??�이???�태
        bool isValid;          // Result validity flag // 결과 ?�효???��?
        float simulationTime;  // Current simulation time [s] // ?�재 ?��??�이???�간 [s]
        float deltaTime;       // Time step [s] // ?�간 간격 [s]
        int stepCount;         // Simulation step count // ?��??�이???�텝 ??

        // Per-component physical states (Interface with Application)
        // 컴포?�트�?물리 ?�태 (Application과의 ?�터?�이??
        TypedPhysicsState* componentStates;  // Physical state of each component // �?컴포?�트??물리 ?�태
        int componentCount;                  // Number of components // 컴포?�트 개수

        // Network state summary
        // ?�트?�크 ?�태 ?�약
        float* nodeVoltages;    // Voltage of each electrical node [V] // �??�기 ?�드???�압 [V]
        float* nodeCurrents;    // Current of each electrical node [A] // �??�기 ?�드???�류 [A]
        float* nodePressures;   // Pressure of each pneumatic node [bar] // �?공압 ?�드???�력 [bar]
        float* nodeMassFlows;   // Mass flow of each pneumatic node [kg/s] // �?공압 ?�드??질량?�량 [kg/s]
        float* nodePositions;   // Position of each mechanical node [mm] // �?기계 ?�드???�치 [mm]
        float* nodeVelocities;  // Velocity of each mechanical node [mm/s] // �?기계 ?�드???�도 [mm/s]

        // Performance statistics
        // ?�능 ?�계
        PhysicsPerformanceStats stats;  // Performance and quality metrics // ?�능 �??�질 지??
    } PhysicsSimulationResult;


/**
 * @brief Physics engine lifecycle management with error handling
 * ?�류 처리�??�함??물리 ?�진 ?�명주기 관�?
 *
 * MEMORY SAFETY ARCHITECTURE:
 * C-style function pointers provide modular, extensible interfaces while
 * maintaining strict memory safety and error handling protocols.
 * 메모�??�전 ?�키?�처:
 * C ?��????�수 ?�인?�는 ?�격??메모�??�전 �??�류 처리 ?�로?�콜???��??�면??
 * 모듈?�의 ?�장 가?�한 ?�터?�이?��? ?�공?�니??
 *
 * LIFECYCLE SAFETY FEATURES:
 * - Structured initialization prevents partial state corruption
 * - Parameter validation prevents invalid configurations
 * - Resource cleanup prevents memory leaks
 * - Error propagation enables recovery strategies
 * ?�명주기 ?�전 기능:
 * - 구조?�된 초기?�는 부분적???�태 ?�상??방�??�니??
 * - ?�라미터 ?�효??검증�? ?�못??구성??방�??�니??
 * - 리소???�리??메모�??�수�?방�??�니??
 * - ?�류 ?�파??복구 ?�략??가?�하�??�니??
 */
    typedef struct PhysicsEngineLifecycle {
        // Creation and initialization
        // ?�성 �?초기??
        int (*Create)(struct PhysicsEngine* engine, int maxComponents, int maxWires);
        int (*Initialize)(struct PhysicsEngine* engine);
        int (*Reset)(struct PhysicsEngine* engine);
        int (*Destroy)(struct PhysicsEngine* engine);

        // Configuration and parameter adjustment
        // ?�정 �??�라미터 조정
        int (*SetTimeStep)(struct PhysicsEngine* engine, float deltaTime);
        int (*SetConvergenceTolerance)(struct PhysicsEngine* engine, float tolerance);
        int (*SetMaxIterations)(struct PhysicsEngine* engine, int maxIter);
        int (*EnableLogging)(struct PhysicsEngine* engine, bool enable);
    } PhysicsEngineLifecycle;

/**
 * @brief Network topology management with automated validation
 * ?�동 ?�효??검증을 ?�한 ?�트?�크 ?�폴로�? 관�?
 *
 * CRITICAL NETWORK SAFETY:
 * Automatic network construction from wiring data with comprehensive
 * validation prevents invalid topologies that could cause simulation
 * instability or incorrect results.
 * 중요 ?�트?�크 ?�전:
 * 배선 ?�이?�로부???�괄?�인 ?�효??검증을 ?�한 ?�동 ?�트?�크 구성?�
 * ?��??�이??불안?�성?�나 부?�확??결과�?초래?????�는 ?�못???�폴로�?�?방�??�니??
 *
 * TOPOLOGY VALIDATION:
 * - Connectivity verification prevents isolated components
 * - Physical consistency checking
 * - Automatic optimization for performance
 * - Error recovery for invalid configurations
 * ?�폴로�? ?�효??검�?
 * - ?�결??검증�? 고립??컴포?�트�?방�??�니??
 * - 물리???��???검??
 * - ?�능???�한 ?�동 최적??
 * - ?�못??구성???�???�류 복구
 */
    typedef struct PhysicsEngineNetworking {
        // Network construction (auto-generated from wiring)
        // ?�트?�크 구성 (배선?�로부???�동 ?�성)
        int (*BuildNetworksFromWiring)(struct PhysicsEngine* engine,
                                       const Wire* wires, int wireCount,
                                       const PlacedComponent* components,
                                       int componentCount);
        int (*UpdateNetworkTopology)(struct PhysicsEngine* engine);
        int (*OptimizeNetworks)(struct PhysicsEngine* engine);

        // Individual network management
        // 개별 ?�트?�크 관�?
        int (*RebuildElectricalNetwork)(struct PhysicsEngine* engine);
        int (*RebuildPneumaticNetwork)(struct PhysicsEngine* engine);
        int (*RebuildMechanicalSystem)(struct PhysicsEngine* engine);

        // Network validation
        // ?�트?�크 검�?
        int (*ValidateNetworks)(struct PhysicsEngine* engine);
        int (*CheckConnectivity)(struct PhysicsEngine* engine);
    } PhysicsEngineNetworking;

/**
 * @brief Real-time simulation control with safety mechanisms
 * ?�전 메커?�즘??갖춘 ?�시�??��??�이???�어
 *
 * REAL-TIME SAFETY FEATURES:
 * Industrial automation requires deterministic, bounded execution times.
 * These functions provide controlled simulation execution with error
 * containment and recovery mechanisms.
 * ?�시�??�전 기능:
 * ?�업 ?�동?�는 결정론적?�고 ?�한???�행 ?�간???�구?�니??
 * ?�러???�수?��? ?�류 ?�제 �?복구 메커?�즘???�해 ?�어???��??�이???�행???�공?�니??
 *
 * EXECUTION SAFETY:
 * - Bounded execution time monitoring
 * - Numerical stability checking
 * - State preservation during failures
 * - Graceful degradation options
 * ?�행 ?�전:
 * - ?�한???�행 ?�간 모니?�링
 * - ?�치???�정??검??
 * - ?�패 ???�태 보존
 * - ?�상?�인 ?�능 ?�???�션
 */
    typedef struct PhysicsEngineSimulation {
        // Simulation control
        // ?��??�이???�어
        int (*RunSimulation)(struct PhysicsEngine* engine, float deltaTime);
        int (*RunSingleStep)(struct PhysicsEngine* engine);
        int (*PauseSimulation)(struct PhysicsEngine* engine);
        int (*ResumeSimulation)(struct PhysicsEngine* engine);
        int (*StopSimulation)(struct PhysicsEngine* engine);

        // Individual system simulation
        // 개별 ?�스???��??�이??
        int (*SolveElectricalSystem)(struct PhysicsEngine* engine, float deltaTime);
        int (*SolvePneumaticSystem)(struct PhysicsEngine* engine, float deltaTime);
        int (*SolveMechanicalSystem)(struct PhysicsEngine* engine, float deltaTime);

        // State management
        // ?�태 관�?
        int (*SaveState)(struct PhysicsEngine* engine, void** stateData,
                         int* stateSize);
        int (*RestoreState)(struct PhysicsEngine* engine, const void* stateData,
                            int stateSize);
    } PhysicsEngineSimulation;

/**
 * @brief Bidirectional data synchronization with validation
 * ?�효??검증을 ?�한 ?�방???�이???�기??
 *
 * CRITICAL DATA INTEGRITY:
 * Safe data exchange between the application and physics engine prevents
 * state corruption that could cause unpredictable behavior or crashes.
 * 중요 ?�이??무결??
 * ?�플리�??�션�?물리 ?�진 간의 ?�전???�이??교환?� ?�측 불�??�한 ?�작?�나
 * 충돌???�발?????�는 ?�태 ?�상??방�??�니??
 *
 * SYNCHRONIZATION SAFETY:
 * - Bidirectional validation prevents inconsistent states
 * - Atomic updates prevent partial state corruption
 * - Type checking prevents invalid data
 * - Bounds checking prevents buffer overflows
 * ?�기???�전:
 * - ?�방???�효??검증�? ?��????�는 ?�태�?방�??�니??
 * - ?�자???�데?�트??부분적???�태 ?�상??방�??�니??
 * - ?�??검?�는 ?�못???�이?��? 방�??�니??
 * - 경계 검?�는 버퍼 ?�버?�로?��? 방�??�니??
 */
    typedef struct PhysicsEngineDataInterface {
        // Application ??PhysicsEngine (Input)
        // Application ??PhysicsEngine (?�력)
        int (*UpdateComponentInputs)(struct PhysicsEngine* engine, int componentId,
                                     const void* inputData);
        int (*SetComponentState)(struct PhysicsEngine* engine, int componentId,
                                 const TypedPhysicsState* state);
        int (*ApplyExternalForces)(struct PhysicsEngine* engine, int componentId,
                                   const float* forces);

        // PhysicsEngine ??Application (Output)
        // PhysicsEngine ??Application (출력)
        int (*GetComponentState)(struct PhysicsEngine* engine, int componentId,
                                 TypedPhysicsState* state);
        int (*GetSimulationResult)(struct PhysicsEngine* engine,
                                   PhysicsSimulationResult* result);
        int (*GetNetworkStates)(struct PhysicsEngine* engine, float* voltages,
                                float* currents, float* pressures, float* flows);

        // Bulk data synchronization
        // ?�???�이???�기??
        int (*SyncAllComponentStates)(struct PhysicsEngine* engine,
                                      PlacedComponent* components, int count);
        int (*UpdateInternalStates)(struct PhysicsEngine* engine,
                                    PlacedComponent* components, int count);
    } PhysicsEngineDataInterface;

/**
 * @brief Comprehensive debugging and monitoring capabilities
 * ?�괄?�인 ?�버�?�?모니?�링 기능
 *
 * DIAGNOSTIC SAFETY FEATURES:
 * Advanced debugging capabilities for troubleshooting physics simulation
 * issues without compromising system stability or performance.
 * 진단 ?�전 기능:
 * ?�스???�정?�이???�능???�?�시?��? ?�으면서 물리 ?��??�이??문제�??�결?�기 ?�한
 * 고급 ?�버�?기능?�니??
 *
 * MONITORING CAPABILITIES:
 * - Real-time performance profiling
 * - Network visualization for debugging
 * - Physical consistency validation
 * - Detailed error reporting and logging
 * 모니?�링 기능:
 * - ?�시�??�능 ?�로?�일�?
 * - ?�버깅을 ?�한 ?�트?�크 ?�각??
 * - 물리???��????�효??검�?
 * - ?�세???�류 보고 �?로깅
 */
    typedef struct PhysicsEngineDebugging {
        // Performance monitoring
        // ?�능 모니?�링
        int (*GetPerformanceStats)(struct PhysicsEngine* engine,
                                   PhysicsPerformanceStats* stats);
        int (*ResetPerformanceCounters)(struct PhysicsEngine* engine);
        int (*EnableProfiling)(struct PhysicsEngine* engine, bool enable);

        // Network visualization (for debugging)
        // ?�트?�크 ?�각??(?�버깅용)
        int (*ExportNetworkGraph)(struct PhysicsEngine* engine, const char* filename,
                                  const char* format);
        int (*PrintNetworkInfo)(struct PhysicsEngine* engine);
        int (*ValidatePhysicalConsistency)(struct PhysicsEngine* engine);

        // Logging and diagnostics
        // 로깅 �?진단
        int (*SetLogLevel)(struct PhysicsEngine* engine, int level);
        int (*EnableDetailedLogging)(struct PhysicsEngine* engine, bool enable);
        const char* (*GetLastError)(struct PhysicsEngine* engine);
    } PhysicsEngineDebugging;


/**
 * @brief Unified physics engine - Central manager for all physics systems
 * ?�합 물리 ?�진 - 모든 물리 ?�스?�의 중앙 관리자
 *
 * CRITICAL ARCHITECTURE DESIGN:
 * This structure serves as the central coordination point for all physics
 * simulations, providing unified management of electrical, pneumatic, and
 * mechanical systems with comprehensive error handling and safety features.
 * ?�심 ?�키?�처 ?�계:
 * ??구조체는 모든 물리 ?��??�이?�의 중앙 조정 지????��???�며,
 * ?�괄?�인 ?�류 처리 �??�전 기능??갖춘 ?�기, 공압, 기계 ?�스?�의 ?�합 관리�? ?�공?�니??
 *
 * SAFETY ARCHITECTURE:
 * - Modular C-style interfaces prevent function pointer corruption
 * - State validation functions prevent invalid operations
 * - Memory pool management prevents allocation failures
 * - Comprehensive error tracking and recovery
 * - Real-time performance monitoring
 * ?�전 ?�키?�처:
 * - 모듈??C ?��????�터?�이?�는 ?�수 ?�인???�상??방�??�니??
 * - ?�태 ?�효??검�??�수???�못???�산??방�??�니??
 * - 메모�??� 관리는 ?�당 ?�패�?방�??�니??
 * - ?�괄?�인 ?�류 추적 �?복구
 * - ?�시�??�능 모니?�링
 *
 * INDUSTRIAL REQUIREMENTS:
 * - Deterministic execution times for real-time systems
 * - Fault tolerance and graceful degradation
 * - Performance optimization for complex networks
 * - Debugging capabilities for troubleshooting
 * ?�업 ?�구?�항:
 * - ?�시�??�스?�을 ?�한 결정론적 ?�행 ?�간
 * - 결함 ?�용 �??�상?�인 ?�능 ?�??
 * - 복잡???�트?�크???�???�능 최적??
 * - 문제 ?�결???�한 ?�버�?기능
 */
    typedef struct PhysicsEngine {
        ElectricalNetwork* electricalNetwork;  // Electrical network // ?�기 ?�트?�크
        PneumaticNetwork* pneumaticNetwork;    // Pneumatic network // 공압 ?�트?�크
        MechanicalSystem* mechanicalSystem;    // Mechanical system // 기계 ?�스??

        TypedPhysicsState* componentPhysicsStates;  // Physical state of each component // �?컴포?�트??물리 ?�태
        int* componentIdToPhysicsIndex;  // Component ID to physics state index mapping // 컴포?�트 ID ??물리?�태 ?�덱??매핑
        int maxComponents;               // Maximum number of components // 최�? 컴포?�트 ??
        int activeComponents;            // Number of active components // ?�성 컴포?�트 ??

        /**
         * CRITICAL MAPPING SYSTEM:
         * Safe translation between component ports and physics network nodes
         * prevents invalid access and ensures data consistency.
         * 중요 매핑 ?�스??
         * 컴포?�트 ?�트?� 물리 ?�트?�크 ?�드 간의 ?�전??변?��?
         * ?�못???�근??방�??�고 ?�이???��??�을 보장?�니??
         *
         * MAPPING SAFETY:
         * - Bounds checking prevents array access violations
         * - Validation prevents invalid component/port combinations
         * - Null pointer protection for unconnected ports
         * 매핑 ?�전:
         * - 경계 검?�는 배열 ?�근 ?�반??방�??�니??
         * - ?�효??검증�? ?�못??컴포?�트/?�트 조합??방�??�니??
         * - ?�결?��? ?��? ?�트???�?????�인??보호
         */
        int** componentPortToElectricalNode;  // [componentId][portId] ??electricalNodeId
        int**
                componentPortToPneumaticNode;  // [componentId][portId] ??pneumaticNodeId
        int** componentPortToMechanicalNode;  // [componentId][portId] ??mechanicalNodeId

        bool isInitialized;  // Initialization completed flag // 초기???�료 ?��?
        bool isRunning;      // Simulation running state // ?��??�이???�행 ?�태
        bool isPaused;       // Paused state // ?�시?��? ?�태
        float currentTime;   // Current simulation time [s] // ?�재 ?��??�이???�간 [s]
        float deltaTime;     // Time step [s] // ?�간 간격 [s]
        int stepCount;       // Total simulation step count // �??��??�이???�텝 ??

        bool isNetworkBuilt;            // Network built flag // ?�트?�크 구성 ?�료 ?��?
        bool isReadyForSimulation;      // Ready for simulation flag // ?��??�이???�행 준�??�료 ?��?
        bool isElectricalNetworkReady;  // Electrical network ready flag // ?�기 ?�트?�크 준�??�료 ?��?
        bool isPneumaticNetworkReady;   // Pneumatic network ready flag // 공압 ?�트?�크 준�??�료 ?��?
        bool isMechanicalSystemReady;   // Mechanical system ready flag // 기계 ?�스??준�??�료 ?��?

        float convergenceTolerance;  // Convergence tolerance // ?�렴 ?�용?�차
        int maxIterations;           // Maximum iterations // 최�? 반복 ?�수
        bool enableLogging;          // Logging enabled flag // 로깅 ?�성???��?
        bool enableProfiling;        // Profiling enabled flag // ?�로?�일�??�성???��?
        int logLevel;                // Log level (0=ERROR, 1=WARN, 2=INFO, 3=DEBUG) // 로그 ?�벨 (0=ERROR, 1=WARN, 2=INFO, 3=DEBUG)

        PhysicsPerformanceStats performanceStats;  // Performance statistics data // ?�능 ?�계 ?�이??
        float performanceUpdateInterval;           // Performance stats update interval [s] // ?�능 ?�계 ?�데?�트 주기 [s]
        float lastPerformanceUpdate;               // Last performance update time [s] // 마�?�??�능 ?�데?�트 ?�간 [s]

        char lastError[256];  // Last error message // 마�?�??�러 메시지
        int lastErrorCode;    // Last error code // 마�?�??�러 코드
        bool hasError;        // Error occurred flag // ?�러 발생 ?��?

        bool (*IsEngineReady)(struct PhysicsEngine* engine);   // Verify engine ready state // ?�진 준�??�태 검�?
        bool (*IsNetworkValid)(struct PhysicsEngine* engine);  // Verify network validity // ?�트?�크 ?�효??검�?
        bool (*IsSafeToRunSimulation)(
                struct PhysicsEngine* engine);  // Verify simulation run safety // ?��??�이???�행 ?�전??검�?

        void* memoryPool;    // Memory pool (for performance optimization) // 메모�??� (?�능 최적?�용)
        int memoryPoolSize;  // Memory pool size [bytes] // 메모�??� ?�기 [bytes]
        int memoryPoolUsed;  // Used memory size [bytes] // ?�용??메모�??�기 [bytes]

        PhysicsEngineLifecycle lifecycle;          // Lifecycle management functions // ?�명주기 관�??�수??
        PhysicsEngineNetworking networking;        // Network construction functions // ?�트?�크 구성 ?�수??
        PhysicsEngineSimulation simulation;        // Simulation control functions // ?��??�이???�어 ?�수??
        PhysicsEngineDataInterface dataInterface;  // Data synchronization functions // ?�이???�기???�수??
        PhysicsEngineDebugging debugging;          // Debugging and monitoring functions // ?�버�?�?모니?�링 ?�수??

    } PhysicsEngine;


/**
 * @brief C-style factory functions with comprehensive error handling
 * ?�괄?�인 ?�류 처리�?갖춘 C ?��????�토�??�수
 *
 * FACTORY SAFETY FEATURES:
 * Safe memory management and initialization for physics engine creation
 * with different configuration presets for various use cases.
 * ?�토�??�전 기능:
 * ?�양???�용 ?��????�???�러 구성 ?�리?�을 ?�용?�여 물리 ?�진???�성?�기 ?�한
 * ?�전??메모�?관�?�?초기??
 *
 * MEMORY SAFETY:
 * - Validated parameter checking prevents invalid configurations
 * - Proper cleanup on initialization failure
 * - Memory allocation validation
 * - Function pointer initialization verification
 * 메모�??�전:
 * - ?�효??검증된 ?�라미터 ?�인?� ?�못??구성??방�??�니??
 * - 초기???�패 ???�절???�리
 * - 메모�??�당 ?�효??검�?
 * - ?�수 ?�인??초기??검�?
 *
 * FACTORY PATTERNS:
 * - Default: Balanced performance and stability
 * - High Performance: Optimized for large networks
 * - Debugging: Enhanced diagnostics and logging
 * ?�토�??�턴:
 * - Default: 균형 ?�힌 ?�능 �??�정??
 * - High Performance: ?�규모 ?�트?�크??최적??
 * - Debugging: ?�상??진단 �?로깅
 */
    extern "C" {
// Create and initialize the physics engine
// 물리?�진 ?�성 �?초기??
    PhysicsEngine* CreatePhysicsEngine(int maxComponents, int maxWires);
    int InitializePhysicsEngine(PhysicsEngine* engine);
    void DestroyPhysicsEngine(PhysicsEngine* engine);

// Create physics engine with default settings (convenience function)
// 기본 ?�정?�로 물리?�진 ?�성 (?�의 ?�수)
    PhysicsEngine* CreateDefaultPhysicsEngine(void);

// Create physics engine with high-performance settings
// 고성???�정?�로 물리?�진 ?�성
    PhysicsEngine* CreateHighPerformancePhysicsEngine(int maxComponents,
                                                      int maxWires);

// Create physics engine with debugging settings
// ?�버�??�정?�로 물리?�진 ?�성
    PhysicsEngine* CreateDebuggingPhysicsEngine(int maxComponents, int maxWires);
    }


/**
 * @brief Default configuration values for reliable operation
 * ?�정?�인 ?�동???�한 기본 구성 �?
 *
 * CONFIGURATION SAFETY:
 * These carefully chosen default values provide stable, reliable operation
 * while allowing customization for specific industrial requirements.
 * 구성 ?�전:
 * ?�중?�게 ?�택????기본값들?� ?�정 ?�업 ?�구?�항???�???�용???�의�??�용?�면??
 * ?�정?�이�??�뢰?????�는 ?�동???�공?�니??
 *
 * VALUE SELECTION CRITERIA:
 * - Industrial automation compatibility
 * - Numerical stability assurance
 * - Performance optimization
 * - Real-time constraint satisfaction
 * �??�택 기�?:
 * - ?�업 ?�동???�환??
 * - ?�치???�정??보장
 * - ?�능 최적??
 * - ?�시�??�약 조건 만족
 */
    namespace PhysicsEngineDefaults {
// Default simulation parameters
// 기본 ?��??�이???�라미터
        const float DEFAULT_TIME_STEP = 1.0f / 60.0f;       // 60 FPS
        const float DEFAULT_CONVERGENCE_TOLERANCE = 1e-6f;  // 1 ppm accuracy // 1 ppm ?�확??
        const int DEFAULT_MAX_ITERATIONS = 100;             // Max 100 iterations // 최�? 100??반복
        const int DEFAULT_MAX_COMPONENTS = 100;             // Max 100 components // 최�? 100�?컴포?�트
        const int DEFAULT_MAX_WIRES = 500;                  // Max 500 wires // 최�? 500�??�?�어

// Performance-related settings
// ?�능 관???�정
        const float DEFAULT_PERFORMANCE_UPDATE_INTERVAL =
                1.0f;                                          // Update performance every 1 second // 1초마???�능 ?�데?�트
        const int DEFAULT_MEMORY_POOL_SIZE = 1024 * 1024;  // 1MB memory pool // 1MB 메모�??�
        const int DEFAULT_LOG_LEVEL = 2;                   // INFO level // INFO ?�벨

// Physical constants
// 물리???�수??
        const float ATMOSPHERIC_PRESSURE = 101325.0f;  // Standard atmospheric pressure [Pa] // ?��? ?�기압 [Pa]
        const float AIR_DENSITY_STP = 1.225f;          // Air density at STP [kg/m³] // ?��??�태 공기밀??[kg/m³]
        const float AIR_VISCOSITY = 1.8e-5f;           // Air viscosity [Pa?�s] // 공기 ?�성계수 [Pa?�s]
        const float GRAVITY = 9.81f;                   // Gravitational acceleration [m/s²] // 중력가?�도 [m/s²]
        const float GAS_CONSTANT = 287.0f;             // Air gas constant [J/kg?�K] // 공기 기체?�수 [J/kg?�K]
        const float SPECIFIC_HEAT_RATIO = 1.4f;        // Air specific heat ratio [-] // 공기 비열�?[-]
    }  // namespace PhysicsEngineDefaults


/**
 * @brief Comprehensive error code system for robust error handling
 * 강력???�류 처리�??�한 ?�괄?�인 ?�류 코드 ?�스??
 *
 * CRITICAL ERROR MANAGEMENT:
 * Systematic error codes enable proper error handling and recovery
 * strategies essential for industrial automation safety.
 * 중요 ?�류 관�?
 * 체계?�인 ?�류 코드???�업 ?�동???�전???�수?�인 ?�절???�류 처리 �?복구 ?�략??
 * 가?�하�??�니??
 *
 * ERROR CODE CLASSIFICATION:
 * - 100s: Initialization and memory errors
 * - 200s: Network topology errors
 * - 300s: Simulation execution errors
 * - 400s: Data synchronization errors
 * - 500s: System-level errors
 * ?�류 코드 분류:
 * - 100번�?: 초기??�?메모�??�류
 * - 200번�?: ?�트?�크 ?�폴로�? ?�류
 * - 300번�?: ?��??�이???�행 ?�류
 * - 400번�?: ?�이???�기???�류
 * - 500번�?: ?�스???��? ?�류
 *
 * ERROR HANDLING STRATEGY:
 * Each error code corresponds to specific recovery procedures,
 * enabling graceful degradation and system stability maintenance.
 * ?�류 처리 ?�략:
 * �??�류 코드???�정 복구 ?�차???�당?�며, ?�상?�인 ?�능 ?�??�??�스???�정???��?�?
 * 가?�하�??�니??
 */
    typedef enum PhysicsEngineError {
        PHYSICS_ENGINE_SUCCESS = 0,  // Success // ?�공

        // Initialization and memory-related errors (100s)
        // 초기??�?메모�?관???�러 (100번�?)
        PHYSICS_ENGINE_ERROR_INITIALIZATION = 100,  // Initialization failed // 초기???�패
        PHYSICS_ENGINE_ERROR_MEMORY_ALLOCATION,     // Memory allocation failed // 메모�??�당 ?�패
        PHYSICS_ENGINE_ERROR_INVALID_PARAMETER,     // Invalid parameter // ?�못???�라미터
        PHYSICS_ENGINE_ERROR_NOT_INITIALIZED,       // Not initialized // 초기?�되지 ?�음

        // Network construction-related errors (200s)
        // ?�트?�크 구성 관???�러 (200번�?)
        PHYSICS_ENGINE_ERROR_NETWORK_BUILD = 200,   // Network build failed // ?�트?�크 구성 ?�패
        PHYSICS_ENGINE_ERROR_INVALID_TOPOLOGY,      // Invalid topology // ?�못???�폴로�?
        PHYSICS_ENGINE_ERROR_DISCONNECTED_NETWORK,  // Disconnected network // ?�결?��? ?��? ?�트?�크
        PHYSICS_ENGINE_ERROR_COMPONENT_NOT_FOUND,   // Component not found // 컴포?�트�?찾을 ???�음

        // Simulation-related errors (300s)
        // ?��??�이??관???�러 (300번�?)
        PHYSICS_ENGINE_ERROR_SIMULATION_FAILED = 300,  // Simulation failed // ?��??�이???�패
        PHYSICS_ENGINE_ERROR_CONVERGENCE_FAILED,       // Convergence failed // ?�렴 ?�패
        PHYSICS_ENGINE_ERROR_NUMERICAL_INSTABILITY,    // Numerical instability // ?�치??불안?�성
        PHYSICS_ENGINE_ERROR_PHYSICAL_INCONSISTENCY,   // Physical inconsistency // 물리??모순

        // Data-related errors (400s)
        // ?�이??관???�러 (400번�?)
        PHYSICS_ENGINE_ERROR_DATA_SYNC = 400,  // Data sync failed // ?�이???�기???�패
        PHYSICS_ENGINE_ERROR_INVALID_STATE,    // Invalid state // ?�못???�태
        PHYSICS_ENGINE_ERROR_BUFFER_OVERFLOW,  // Buffer overflow // 버퍼 ?�버?�로??
        PHYSICS_ENGINE_ERROR_TYPE_MISMATCH,    // Type mismatch // ?�??불일�?

        // System-related errors (500s)
        // ?�스??관???�러 (500번�?)
        PHYSICS_ENGINE_ERROR_SYSTEM = 500,    // System error // ?�스???�러
        PHYSICS_ENGINE_ERROR_THREAD_FAILURE,  // Thread failure // ?�레???�패
        PHYSICS_ENGINE_ERROR_IO_ERROR,        // I/O error // ?�출???�러
        PHYSICS_ENGINE_ERROR_UNKNOWN          // Unknown error // ?????�는 ?�러
    } PhysicsEngineError;

/**
 * @brief Error code to string conversion utility
 * @param error Error code to convert
 * @return Human-readable error description
 * ?�류 코드�?문자?�로 변?�하???�틸리티
 * @param error 변?�할 ?�류 코드
 * @return ?�람???�을 ???�는 ?�류 ?�명
 *
 * DEBUGGING SUPPORT:
 * Provides clear, actionable error messages for troubleshooting
 * and maintenance in industrial environments.
 * ?�버�?지??
 * ?�업 ?�경?�서??문제 ?�결 �??��?보수�??�해 명확?�고 ?�행 가?�한 ?�류 메시지�??�공?�니??
 */
    const char* PhysicsEngineErrorToString(PhysicsEngineError error);

}  // namespace plc
#endif  // PLC_EMULATOR_INCLUDE_PLC_EMULATOR_PHYSICS_PHYSICS_ENGINE_H_