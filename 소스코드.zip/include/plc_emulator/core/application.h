// application.h

//
// Main application class for the PLC emulator.
// PLC ?�???�씠?곗쓽 硫붿???좏뵆?��???��???�???�엯??�떎.
//
// This file manages the application lifecycle and coordinates mode switching.
// ?????��?? ?좏뵆?��???��????�챸二쇨린瑜??�?�ы븯??紐⑤�?�??꾪솚??議곗???�땲??
//

#ifndef PLC_EMULATOR_INCLUDE_PLC_EMULATOR_CORE_APPLICATION_H_
#define PLC_EMULATOR_INCLUDE_PLC_EMULATOR_CORE_APPLICATION_H_

#include "imgui.h"
#include "plc_emulator/core/data_types.h"
#include "plc_emulator/core/plc_simulator_core.h"
#include "plc_emulator/physics/physics_engine.h"
#include "plc_emulator/programming/compiled_plc_executor.h"
#include "plc_emulator/programming/programming_mode.h"
#include "plc_emulator/project/project_file_manager.h"

#include <mutex>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

struct GLFWwindow;

namespace plc {

    class ProgrammingMode;

//
// The main class that orchestrates the entire PLC emulator application.
// ?꾩껜 PLC ?�???�씠???좏뵆?��???��???�앷???�뒗 硫붿????�???�엯??�떎.
//
    class Application {
    public:
        /**
         * @brief Constructs the Application object and initializes default values.
         * Application 媛앹껜瑜???�꽦??��?湲곕??��믪쓣 ?�덇�?뷀빀??�떎.
         */
        explicit Application(bool enable_debug_mode);

        /**
         * @brief Destructor. Ensures all resources are cleaned up properly.
         * ???��?? 紐⑤�??�ъ냼??? ??�?��?�쾶 ?뺣━??�룄�?蹂댁???�땲??
         */
        ~Application();

        // Disable copy and assignment to prevent accidental duplication.
        // ??�룄??? ??? 蹂듭?�瑜?諛⑹???�린 ?꾪빐 蹂듭�?�??좊떦????��??깊솕??�땲??
        Application(const Application&) = delete;
        Application& operator=(const Application&) = delete;

        /**
         * @brief Initializes all subsystems, including the window, GUI, and simulator.
         * ??�룄?? GUI, ?????�씠?�? ??�??紐⑤�???�쐞 ??�뒪??�쓣 ?�덇�?뷀빀??�떎.
         * @return True if initialization is successful, false otherwise.
         * ?�덇�?붿뿉 ?깃났??�㈃ true, 洹몃?�吏? ??�쑝�?false??諛섑???�땲??
         */
        bool Initialize();

        /**
         * @brief Starts and runs the main application loop.
         * 硫붿???좏뵆?��???��??�⑦봽瑜???�옉??��???�뻾??�땲??
         */
        void Run();

        /**
         * @brief Shuts down the application and releases all resources.
         * ?좏뵆?��???��???�낅�??��?紐⑤�??�ъ냼??? ??�젣??�땲??
         */
        void Shutdown();

        void UpdateTouchGesture(float zoom_delta, ImVec2 pan_delta,
                                bool active);
        void SetPanInputActive(bool active);
        void SetTouchAnchor(ImVec2 screen_pos);
        void RegisterWin32RightClick();
        void RegisterWin32SideClick();
        void RegisterWin32SideDown(bool is_down);
        bool IsPointInCanvas(ImVec2 screen_pos) const;
        bool IsDebugEnabled() const;
        void DebugLog(const std::string& message);
        void QueuePhysicsWarningDialog(const std::string& message);
        /**
         * @brief Saves the current project state to a .csv file.
         * ?꾩옱 ?꾨줈??�듃 ?곹깭??.csv ???��?????ν빀??�떎.
         * @param filePath The path to save the project file.
         * filePath???꾨줈??�듃 ???��?????ν�?寃쎈�??�땲??
         * @param projectName An optional name for the project.
         * projectName?? ?꾨줈??�듃???좏깮????��??�땲??
         * @return True on successful save, false otherwise.
         * ???μ�??깃났??�㈃ true, 洹몃?�吏? ??�쑝�?false??諛섑???�땲??
         */
        bool SaveProject(const std::string& filePath,
                         const std::string& projectName = "");

        /**
         * @brief Loads a project from a .csv file.
         * .csv ???��濡쒕????꾨줈??�듃???�덈???�땲??
         * @param filePath The path of the project file to load.
         * filePath???�덈????꾨줈??�듃 ???��??寃쎈�??�땲??
         * @return True on successful load, false otherwise.
         * ?�덈???�린???깃났??�㈃ true, 洹몃?�吏? ??�쑝�?false??諛섑???�땲??
         */
        bool LoadProject(const std::string& filePath);

    private:
        /**
         * @brief Initializes the GLFW window.
         * GLFW ??�룄?�? ?�덇�?뷀빀??�떎.
         */
        bool InitializeWindow();

        /**
         * @brief Initializes the ImGui context.
         * ImGui ?�⑦???�듃???�덇�?뷀빀??�떎.
         */
        bool InitializeImGui();

        /**
         * @brief Sets up a custom visual style for ImGui.
         * ImGui????????????뺤쓽 ??���???????�쓣 ??�젙??�땲??
         */
        void SetupCustomStyle();

        /**
         * @brief Processes user input for the current frame.
         * ?꾩옱 ?꾨젅?꾩뿉 ???????????�젰??泥섎???�땲??
         */
        void ProcessInput();

        /**
         * @brief Main update function called once per frame.
         * ?꾨젅?꾨떦 ??�??몄텧??�뒗 硫붿????�뜲??�듃 ??�닔??�땲??
         */
        void Update();

        /**
         * @brief Updates the physics simulation state.
         * ?�쇰???????�씠???곹깭????�뜲??�듃??�땲??
         */
        void UpdatePhysics();

        /**
         * @brief Simulates basic physics phenomena, independent of the PLC state.
         * PLC ?곹깭?? ??�┰?곸쑝�?湲곕??곸씤 ?�쇰???꾩긽???????�씠??��???�떎.
         */
        void UpdateBasicPhysics();

        /**
         * @brief Executes one scan of the loaded ladder logic program.
         * ?�덈?????�뜑 濡쒖�??꾨줈洹몃???????�틪????�뻾??�땲??
         */
        void SimulateLoadedLadder();

        /**
         * @brief Gets the current state of a PLC device (e.g., input, output).
         * PLC ?붾컮??�뒪(?? ??�젰, ?�쒕?????꾩옱 ?곹깭??媛?몄샃??�떎.
         */
        bool GetPlcDeviceState(const std::string& address);

        /**
         * @brief Sets the state of a PLC device.
         * PLC ?붾컮??�뒪???곹깭????�젙??�땲??
         */
        void SetPlcDeviceState(const std::string& address, bool state);

        /**
         * @brief Loads a ladder program from a specified .ld file.
         * 吏?뺣맂 .ld ???��濡쒕?????�뜑 ?꾨줈洹몃????�덈???�땲??
         * @param filepath Path to the .ld file.
         * filepath??.ld ???��??寃쎈�??�땲??
         */
        void LoadLadderProgramFromLD(const std::string& filepath);

        /**
         * @brief Converts a string representation of an instruction to its enum type.
         * 紐낅�??�쓽 ?�몄?????�쁽????�????�굅??????�쑝�?蹂??��???�떎.
         */
        LadderInstructionType StringToInstructionType(const std::string& str);

        /**
         * @brief Synchronizes the ladder program from the programming mode to the simulator.
         * ?꾨줈洹몃?�諛?紐⑤�????�뜑 ?꾨줈洹몃????????�씠?곕줈 ??�린?뷀빀??�떎.
         */
        void SyncLadderProgramFromProgrammingMode();

        /**
         * @brief Creates a default ladder program for testing and initialization.
         * ???��??�??�덇�?�? ?꾪빐 湲곕????�뜑 ?꾨줈洹몃?????�꽦??�땲??
         */
        void CreateDefaultTestLadderProgram();

        /**
         * @brief Compiles the current ladder program and loads it into the PLC executor.
         * ?꾩옱 ??�뜑 ?꾨줈洹몃????�댄???�븯??PLC ??�뻾湲곗�?濡쒕�??�땲??
         */
        void CompileAndLoadLadderProgram();

        /**
         * @brief Simulates the electrical network connecting components.
         * ?�댄�??�듃???곌껐??�뒗 ?꾧린 ??�듃??�겕???????�씠??��???�떎.
         */
        void SimulateElectrical();

        /**
         * @brief Updates the internal logic of placed components.
         * 諛곗????�댄�??�듃????�? 濡쒖�????�뜲??�듃??�땲??
         */
        void UpdateComponentLogic();

        /**
         * @brief Simulates the pneumatic network connecting components.
         * ?�댄�??�듃???곌껐??�뒗 ?�듭�???�듃??�겕???????�씠??��???�떎.
         */
        void SimulatePneumatic();

        /**
         * @brief Updates the state of actuators (e.g., cylinders) based on simulation.
         * ?????�씠??寃곌????곕씪 ??�텛?�?��???? ??�┛?????곹깭????�뜲??�듃??�땲??
         */
        void UpdateActuators();

        /**
         * @brief Retrieves the port information for a given component.
         * 二쇱뼱吏??�댄�??�듃???????뺣낫??媛?몄샃??�떎.
         */
        std::vector<std::pair<int, bool>> GetPortsForComponent(
                const PlacedComponent& comp);

        /**
         * @brief Synchronizes PLC output states to the physics engine's electrical network.
         * PLC ?�쒕???곹깭???�쇰???붿쭊???꾧린 ??�듃??�겕?? ??�린?뷀빀??�떎.
         */
        void SyncPLCOutputsToPhysicsEngine();

        /**
         * @brief Synchronizes results from the physics engine back to the application state.
         * ?�쇰???붿쭊??寃곌?�瑜??좏뵆?��???��??곹깭�???�떆 ??�린?뷀빀??�떎.
         */
        void SyncPhysicsEngineToApplication();

        /**
         * @brief Updates and displays physics engine performance statistics.
         * ?�쇰???붿쭊???깅뒫 ???��瑜???�뜲??�듃??��???�떆??�땲??
         */
        void UpdatePhysicsPerformanceStats();

        /**
         * @brief Renders the entire application scene for the current frame.
         * ?꾩옱 ?꾨젅?꾩뿉 ?????꾩껜 ?좏뵆?��???��??λ??????��留곹빀??�떎.
         */
        void Render();

        /**
         * @brief Cleans up resources before shutting down.
         * ?�낅�??�린 ?꾩뿉 ?�ъ냼??? ?뺣━??�땲??
         */
        void Cleanup();

        /**
         * @brief Updates the screen positions of all component ports.
         * 紐⑤�??�댄�??�듃 ??????붾㈃ ?꾩튂????�뜲??�듃??�땲??
         */
        void UpdatePortPositions();

        /**
         * @brief Renders the main user interface using ImGui.
         * ImGui???????�뿬 硫붿????????명꽣??�씠??? ???��留곹빀??�떎.
         */
        void RenderUI();

        /**
         * @brief Renders the UI specific to the wiring mode.
         * 諛곗�?紐⑤�???뱁솕??UI?????��留곹빀??�떎.
         */
        void RenderWiringModeUI();

        /**
         * @brief Renders the application header bar.
         * ?좏뵆?��???��???�뜑 諛붾? ???��留곹빀??�떎.
         */
        void RenderHeader();

        /**
         * @brief Renders the toolbar with mode and tool selection.
         * 紐⑤�?�??꾧뎄 ?좏깮 湲곕?????�뒗 ??��?��????��留곹빀??�떎.
         */
        void RenderToolbar();

        /**
         * @brief Renders the main content area of the application.
         * ?좏뵆?��???��??�??�섑?�痢??곸뿭?????��留곹빀??�떎.
         */
        void RenderMainArea();

        /**
         * @brief Renders the real-time PLC debug panel.
         * ??�떆�?PLC ?붾쾭�???�꼸?????��留곹빀??�떎.
         */
        void RenderPLCDebugPanel();
        void RenderPhysicsWarningDialog();
        /**
         * @brief Converts world coordinates to screen coordinates.
         * ?붾뱶 ?�뚰몴瑜??붾㈃ ?�뚰몴濡?蹂??��???�떎.
         */
        ImVec2 WorldToScreen(const ImVec2& world_pos) const;

        /**
         * @brief Converts screen coordinates to world coordinates.
         * ?붾㈃ ?�뚰몴瑜??붾뱶 ?�뚰몴濡?蹂??��???�떎.
         */
        ImVec2 ScreenToWorld(const ImVec2& screen_pos) const;

        /**
         * @brief Renders the list of available components.
         * ????媛?ν�??�댄�??�듃 紐⑸�?????��留곹빀??�떎.
         */
        void RenderComponentList();

        /**
         * @brief Renders all components placed in the workspace.
         * ?묒뾽 ?�듦�??諛곗???紐⑤�??�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderPlacedComponents(ImDrawList* draw_list);

        /**
         * @brief Handles the start of a component drag operation from the component list.
         * ?�댄�??�듃 紐⑸�?�?�� ?�댄�??�듃 ??�옒�??묒뾽 ??�옉??泥섎???�땲??
         */
        void HandleComponentDragStart(int componentIndex);

        /**
         * @brief Handles the ongoing component drag operation.
         * 吏꾪�?以묒???�댄�??�듃 ??�옒�??묒뾽??泥섎???�땲??
         */
        void HandleComponentDrag();

        /**
         * @brief Handles dropping a component onto the workspace.
         * ?묒뾽 ?�듦�???�댄�??�듃????�∼??�뒗 ?묒뾽??泥섎???�땲??
         */
        void HandleComponentDrop(Position position);

        /**
         * @brief Handles the selection of a placed component.
         * 諛곗????�댄�??�듃???좏깮??泥섎???�땲??
         */
        void HandleComponentSelection(int instanceId);

        /**
         * @brief Deletes the currently selected component.
         * ?꾩옱 ?좏깮???�댄�??�듃???????�땲??
         */
        void DeleteSelectedComponent();

        /**
         * @brief Handles the start of moving an already placed component.
         * ??�? 諛곗????�댄�??�듃????��???�옉??泥섎???�땲??
         */
        void HandleComponentMoveStart(int instanceId, ImVec2 mousePos);

        /**
         * @brief Handles the end of a component move operation.
         * ?�댄�??�듃 ??��??묒뾽???�낅즺瑜?泥섎???�땲??
         */
        void HandleComponentMoveEnd();

        /**
         * @brief Renders a PLC component.
         * PLC ?�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderPLCComponent(ImDrawList* draw_list, const PlacedComponent& comp,
                                ImVec2 screen_pos);
        /**
         * @brief Renders an FRL (Filter, Regulator, Lubricator) unit component.
         * FRL(?꾪꽣, ??�랠??�씠?? ??�솢�? ?좊떅 ?�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderFRLComponent(ImDrawList* draw_list, const PlacedComponent& comp,
                                ImVec2 screen_pos);
        /**
         * @brief Renders a manifold component.
         * 留ㅻ???��??�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderManifoldComponent(ImDrawList* draw_list,
                                     const PlacedComponent& comp, ImVec2 screen_pos);
        /**
         * @brief Renders a limit switch component.
         * ?��?????�쐞�??�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderLimitSwitchComponent(ImDrawList* draw_list,
                                        const PlacedComponent& comp,
                                        ImVec2 screen_pos);
        /**
         * @brief Renders a generic sensor component.
         * ??�컲 ??�꽌 ?�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderSensorComponent(ImDrawList* draw_list, const PlacedComponent& comp,
                                   ImVec2 screen_pos);
        /**
         * @brief Renders a cylinder component.
         * ??�┛???�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderCylinderComponent(ImDrawList* draw_list,
                                     const PlacedComponent& comp, ImVec2 screen_pos);
        /**
         * @brief Renders a single-solenoid valve component.
         * ??�룞 ?붾젅?몄씠??諛몃???�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderValveSingleComponent(ImDrawList* draw_list,
                                        const PlacedComponent& comp,
                                        ImVec2 screen_pos);
        /**
         * @brief Renders a double-solenoid valve component.
         * 蹂듬�??붾젅?몄씠??諛몃???�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderValveDoubleComponent(ImDrawList* draw_list,
                                        const PlacedComponent& comp,
                                        ImVec2 screen_pos);
        /**
         * @brief Renders a button unit component.
         * 踰꾪???좊떅 ?�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderButtonUnitComponent(ImDrawList* draw_list,
                                       const PlacedComponent& comp,
                                       ImVec2 screen_pos);
        /**
         * @brief Renders a power supply component.
         * ?꾩썝 ?�듦???μ???�댄�??�듃?????��留곹빀??�떎.
         */
        void RenderPowerSupplyComponent(ImDrawList* draw_list,
                                        const PlacedComponent& comp,
                                        ImVec2 screen_pos);

        /**
         * @brief Renders the main canvas for wiring and component placement.
         * 諛곗�?�??�댄�??�듃 諛곗?�瑜??꾪븳 硫붿??�?���??? ???��留곹빀??�떎.
         */
        void RenderWiringCanvas();

        // RenderWiringCanvas helper functions
        // RenderWiringCanvas ??????�닔??

        /**
         * @brief Handles user interaction for adjusting FRL pressure.
         * FRL ?뺣젰 議곗????꾪븳 ??????곹샇?묒슜??泥섎???�땲??
         */
        bool HandleFRLPressureAdjustment(ImVec2 mouse_world_pos, const ImGuiIO& io);

        /**
         * @brief Handles camera zooming and panning on the canvas.
         * �?���??�뿉??�쓽 移�?�???�?/?�뺤??�???��??泥섎???�땲??
         */
        void HandleZoomAndPan(bool is_canvas_hovered, const ImGuiIO& io,
                              bool frl_handled, bool& wheel_handled);

        /**
         * @brief Renders the background grid on the canvas.
         * �?���??�뿉 諛곌�?洹몃???? ???��留곹빀??�떎.
         */
        void RenderGrid(ImDrawList* draw_list);

        /**
         * @brief Handles component dropping and wire deletion based on user input.
         * ???????�젰???곕Ⅸ ?�댄�??�듃 ??�∼ �??꾩꽑 ???�瑜?泥섎???�땲??
         */
        void HandleComponentDropAndWireDelete(bool is_canvas_hovered,
                                              ImVec2 mouse_world_pos,
                                              const ImGuiIO& io);

        /**
         * @brief Handles user interactions in wire editing mode.
         * ?꾩꽑 ?몄쭛 紐⑤�?�?��????????곹샇?묒슜??泥섎???�땲??
         */
        void HandleWireEditMode(ImVec2 mouse_world_pos);

        /**
         * @brief Handles user interactions in selection mode.
         * ?좏깮 紐⑤�?�?��????????곹샇?묒슜??泥섎???�땲??
         */
        void HandleSelectMode(bool is_canvas_hovered, ImVec2 mouse_world_pos);

        /**
         * @brief Handles user interactions in wire connection mode.
         * ?꾩꽑 ?곌껐 紐⑤�?�?��????????곹샇?묒슜??泥섎???�땲??
         */
        void HandleWireConnectionMode(bool is_canvas_hovered, ImVec2 mouse_world_pos);

        /**
         * @brief Renders the main content of the canvas (components, wires, etc.).
         * �?���??�쓽 �??�섑?�痢??�댄�??�듃, ?꾩꽑 ???????��留곹빀??�떎.
         */
        void RenderCanvasContent(ImDrawList* draw_list, ImVec2 mouse_world_pos);

        /**
         * @brief Shows a tooltip with information about the port under the cursor.
         * ?�ㅼ�??꾨옒????�뒗 ??????????뺣낫媛 ??�릿 ??�똻????�떆??�땲??
         */
        void ShowPortTooltip(bool is_canvas_hovered, ImVec2 mouse_world_pos);

        /**
         * @brief Displays an overlay with help text for camera controls.
         * 移�?�????�뼱???????�?�???�뒪?�? ??�뒗 ??�쾭??�씠????�떆??�땲??
         */
        void ShowCameraHelpOverlay();

        /**
         * @brief Starts the process of drawing a new wire from a specified port.
         * 吏?뺣맂 ????�?�� ???꾩꽑??洹몃????꾨줈?몄뒪????�옉??�땲??
         */
        void StartWireConnection(int componentId, int portId, ImVec2 portWorldPos);

        /**
         * @brief Updates the endpoint of the wire being drawn to the mouse position.
         * 洹몃??��?????�뒗 ?꾩꽑????�젏??留덉????꾩튂�???�뜲??�듃??�땲??
         */
        void UpdateWireDrawing(ImVec2 mousePos);

        /**
         * @brief Completes a wire connection to a target port.
         * ??????????????꾩꽑 ?곌껐???꾨즺??�땲??
         */
        void CompleteWireConnection(int componentId, int portId, ImVec2 portWorldPos);

        /**
         * @brief Renders all established wires on the canvas.
         * �?���??�뿉 ??�젙??紐⑤�??꾩꽑?????��留곹빀??�떎.
         */
        void RenderWires(ImDrawList* draw_list);

        /**
         * @brief Deletes a wire by its ID.
         * ID�??꾩꽑???????�땲??
         */
        void DeleteWire(int wireId);

        /**
         * @brief Handles a click on a waypoint of a wire.
         * ?꾩꽑????�씠?????寃쎌?�?? ??�???泥섎???�땲??
         */
        void HandleWayPointClick(ImVec2 worldPos, bool use_port_snap_only);

        /**
         * @brief Adds a new waypoint to the wire currently being drawn.
         * ?꾩옱 洹몃??��?????�뒗 ?꾩꽑??????�씠????�? ?�붽???�땲??
         */
        void AddWayPoint(ImVec2 position);

        /**
         * @brief Renders the temporary wire being drawn by the user.
         * ????�? 洹몃?��???�뒗 ?꾩떆 ?꾩꽑?????��留곹빀??�떎.
         */
        void RenderTemporaryWire(ImDrawList* draw_list);

        /**
         * @brief Handles the selection of a wire.
         * ?꾩꽑 ?좏깮??泥섎???�땲??
         */
        void HandleWireSelection(ImVec2 worldPos);

        /**
         * @brief Finds a wire at a given world position.
         * 二쇱뼱吏??붾뱶 ?꾩튂?�?�� ?꾩꽑??李얠???�떎.
         */
        Wire* FindWireAtPosition(ImVec2 worldPos, float tolerance = 5.0f);

        /**
         * @brief Finds a waypoint in a wire at a given world position.
         * 二쇱뼱吏??붾뱶 ?꾩튂?�?�� ?꾩꽑????�씠????�? 李얠???�떎.
         */
        int FindWayPointAtPosition(Wire& wire, ImVec2 worldPos, float radius = 8.0f);

        /**
         * @brief Checks if a connection between two ports is valid.
         * ??????媛꾩???곌껐???좏슚??? ?뺤씤??�땲??
         */
        bool IsValidWireConnection(const Port& fromPort, const Port& toPort);

        /**
         * @brief Finds a port at a given world position.
         * 二쇱뼱吏??붾뱶 ?꾩튂?�?�� ???�瑜?李얠???�떎.
         */
        Port* FindPortAtPosition(ImVec2 worldPos, int& outComponentId);

        /**
         * @brief Applies all enabled snap settings to a position.
         * ??�꽦?붾맂 紐⑤�???�깄 ??�젙???꾩튂???곸슜??�땲??
         */
        ImVec2 ApplySnap(ImVec2 position, bool isWirePoint = false);

        /**
         * @brief Snaps a position to the grid.
         * ?꾩튂??洹몃???�뿉 ??�깄??�땲??
         */
        ImVec2 ApplyGridSnap(ImVec2 position);

        /**
         * @brief Snaps a position to the nearest component port.
         * ?꾩튂??媛??媛源뚯???�댄�??�듃 ???????�깄??�땲??
         */
        ImVec2 ApplyPortSnap(ImVec2 position);

        /**
         * @brief Snaps a position to align horizontally or vertically with a reference point.
         * 湲곗??�?�� ??�룊 ?�?�� ??�쭅??�줈 ?뺣젹??�룄�??꾩튂????�깄??�땲??
         */
        ImVec2 ApplyLineSnap(ImVec2 position, ImVec2 referencePoint,
                             bool force_orthogonal);

        /**
         * @brief Renders visual guides for snapping.
         * ??�깄???꾪븳 ??�컖??媛??�뱶瑜????��留곹빀??�떎.
         */
        void RenderSnapGuides(ImDrawList* draw_list, ImVec2 worldSnapPos);

        // Pointer to the main GLFW window.
        // 硫붿??GLFW ??�룄?곗뿉 ????????곗엯??�떎.
        GLFWwindow* window_;

        // Current operating mode (e.g., Wiring, Programming).
        // ?꾩옱 ?묐룞 紐⑤�??? 諛곗�? ?꾨줈洹몃?�諛???�땲??
        Mode current_mode_;

        // Currently selected tool (e.g., Select, Wire).
        // ?꾩옱 ?좏깮???꾧뎄(?? ?좏깮, ?꾩꽑)??�땲??
        ToolType current_tool_;

        // Flag indicating if the main application loop is running.
        // 硫붿???좏뵆?��???��??�⑦봽媛? ??�뻾 以묒?�吏? ?????�?????��洹몄???�떎.
        bool running_;

        // Flag indicating if the PLC simulation is running.
        // PLC ?????�씠??�씠 ??�뻾 以묒?�吏? ?????�?????��洹몄???�떎.
        bool is_plc_running_;

        // Default window width and height constants.
        // 湲곕????�룄????�퉬 �??믪씠 ?곸닔??�땲??
        static constexpr int kWindowWidth = 1440;
        static constexpr int kWindowHeight = 1024;

        // Collection of all components placed in the workspace.
        // ?묒뾽 ?�듦�??諛곗???紐⑤�??�댄�??�듃???�щ젆??�엯??�떎.
        std::vector<PlacedComponent> placed_components_;
        // ID of the currently selected component.
        // ?꾩옱 ?좏깮???�댄�??�듃??ID??�땲??
        int selected_component_id_;
        // Counter to generate unique instance IDs for new components.
        // ???�댄�??�듃???꾪븳 ?�좎?� ?몄뒪??�뒪 ID????�꽦??�뒗 移댁??곗엯??�떎.
        int next_instance_id_;

        // State variables for component drag-and-drop and movement.
        // ?�댄�??�듃 ??�옒�?????�∼ �???��???꾪븳 ?곹깭 蹂??�뱾??�땲??
        bool is_dragging_;
        int dragged_component_index_;
        bool is_moving_component_;
        int moving_component_id_;
        ImVec2 drag_start_offset_;

        // Collection of all wires in the workspace.
        // ?묒뾽 ?�듦�????�뒗 紐⑤�??꾩꽑???�щ젆??�엯??�떎.
        std::vector<Wire> wires_;
        // Counter for generating unique wire IDs.
        // ?�좎?�???꾩꽑 ID????�꽦??�린 ?꾪븳 移댁??곗엯??�떎.
        int next_wire_id_;
        // ID of the currently selected wire.
        // ?꾩옱 ?좏깮???꾩꽑??ID??�땲??
        int selected_wire_id_;

        // State variables for the interactive wire creation process.
        // ?곹샇?묒슜?곸씤 ?꾩꽑 ??�꽦 ?�쇱????꾪븳 ?곹깭 蹂??�뱾??�땲??
        bool is_connecting_;
        int wire_start_component_id_;
        int wire_start_port_id_;
        ImVec2 wire_start_pos_;
        ImVec2 wire_current_pos_;
        std::vector<Position> current_way_points_;
        Port temp_port_buffer_;

        // State variables for editing an existing wire's waypoints.
        // 湲곗???꾩꽑????�씠????�? ?몄쭛??�린 ?꾪븳 ?곹깭 蹂??�뱾??�땲??
        WireEditMode wire_edit_mode_;
        int editing_wire_id_;
        int editing_point_index_;

        // State for the workspace camera's pan and zoom.
        // ?묒뾽 ?�듦�?移�?�??�쓽 ??��?�??�?/?�뺤?�瑜??꾪븳 ?곹깭??�땲??
        ImVec2 camera_offset_;
        float camera_zoom_;
        ImVec2 canvas_top_left_;
        ImVec2 canvas_size_;

        // Configuration for snapping behavior.
        // ??�깄 ??�옉???????�ъ꽦??�땲??
        SnapSettings snap_settings_;

        // Maps storing simulation state data for each component port.
        // �??�댄�??�듃 ??????????????�씠???곹깭 ?곗씠?�? ???ν�??留듭???�떎.
        std::map<std::pair<int, int>, Position> port_positions_;
        std::map<std::pair<int, int>, float> port_voltages_;
        std::map<std::pair<int, int>, float> port_pressures_;

        // Data for the loaded ladder logic and the live state of PLC devices.
        // ?�덈?????�뜑 濡쒖쭅�?PLC ?붾컮??�뒪????�떆�??곹깭???????곗씠?곗엯??�떎.
        LadderProgram loaded_ladder_program_;
        std::map<std::string, bool> plc_device_states_;
        std::map<std::string, TimerState> plc_timer_states_;
        std::map<std::string, CounterState> plc_counter_states_;

        // Smart pointers to the major subsystems of the application.
        // ?좏뵆?��???��??二쇱????�쐞 ??�뒪??�쓣 媛?�ы궎????�쭏??????곗엯??�떎.
        std::unique_ptr<ProgrammingMode> programming_mode_;
        std::unique_ptr<PLCSimulatorCore> simulator_core_;
        PhysicsEngine* physics_engine_;
        std::unique_ptr<CompiledPLCExecutor> compiled_plc_executor_;
        std::unique_ptr<ProjectFileManager> project_file_manager_;

        // State variables for the real-time debugging and logging system.
        // ??�떆�??붾쾭�?�?濡쒓????�뒪??�쓣 ?꾪븳 ?곹깭 蹂??�뱾??�땲??
        bool debug_mode_requested_;
        bool debug_mode_;
        bool enable_debug_logging_;
        int debug_update_counter_;
        std::string debug_log_buffer_;
        bool show_physics_warning_dialog_;
        std::string physics_warning_message_;
        std::mutex physics_warning_mutex_;
        ImVec2 last_pointer_world_pos_;
        double last_pointer_move_time_;
        double last_auto_waypoint_time_;
        bool touch_gesture_active_;
        float touch_zoom_delta_;
        ImVec2 touch_pan_delta_;
        bool last_pointer_is_pan_input_;
        ImVec2 touch_anchor_screen_pos_;
        bool prev_right_button_down_;
        bool prev_side_button_down_;
        bool win32_right_click_;
        bool win32_side_click_;
        bool win32_side_down_;

        /**
         * @brief Toggles the comprehensive debug mode on or off.
         * ?�낇빀 ?붾쾭�?紐⑤뱶瑜??�쒓�???뺣땲??
         */
        void ToggleDebugMode();

        /**
         * @brief Updates and logs debug information to the console if enabled.
         * ??�꽦?붾맂 寃쎌???�섏????붾쾭�??뺣낫????�뜲??�듃??��?湲곕�??�땲??
         */
        void UpdateDebugLogging();

        /**
         * @brief Logs the state of all placed components to the debug buffer.
         * 諛곗???紐⑤�??�댄�??�듃???곹깭???붾쾭�?踰꾪???湲곕�??�땲??
         */
        void LogComponentStates();

        /**
         * @brief Logs the overall state of the physics engine to the debug buffer.
         * ?�쇰???붿쭊???꾨컲?곸씤 ?곹깭???붾쾭�?踰꾪???湲곕�??�땲??
         */
        void LogPhysicsEngineStates();

        /**
         * @brief Logs the state of the electrical network to the debug buffer.
         * ?꾧린 ??�듃??�겕???곹깭???붾쾭�?踰꾪???湲곕�??�땲??
         */
        void LogElectricalNetwork();

        /**
         * @brief Logs the state of the pneumatic network to the debug buffer.
         * ?�듭�???�듃??�겕???곹깭???붾쾭�?踰꾪???湲곕�??�땲??
         */
        void LogPneumaticNetwork();

        /**
         * @brief Logs the state of the mechanical systems (e.g., cylinders) to the debug buffer.
         * 湲곌????�뒪???? ??�┛?????곹깭???붾쾭�?踰꾪???湲곕�??�땲??
         */
        void LogMechanicalSystem();

        /**
         * @brief Prints a message to the system console.
         * ??�뒪???�섏???硫붿?�吏????�쒕???�땲??
         */
        void PrintDebugToConsole(const std::string& message);
    };

}  // namespace plc
#endif  // PLC_EMULATOR_INCLUDE_PLC_EMULATOR_CORE_APPLICATION_H_
